﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManagerScript : MonoBehaviour {

	public string[] playerName = new string[4];
	public string[] answer = new string[4];
	public int[] score = new int[4];
    public Dictionary<string, int> person = new Dictionary<string, int>();

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
